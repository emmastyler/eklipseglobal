<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kyc extends Model
{
    use HasFactory;
     /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'firstname',
        'lastname',
        'email',
        'phonenumber',
        'dob',
        'nationality',
        'address1',
        'address2',
        'zipcode',
        'city',
        'frontImage',
        'backImage',
        'status'
    ];

}
