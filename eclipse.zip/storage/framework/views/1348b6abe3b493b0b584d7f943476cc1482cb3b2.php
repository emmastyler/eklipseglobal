
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Eclipse Crypto is a modern and elegant landing page, created for Eclipse Agencies and digital crypto currency investment website.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- Site Title  -->
    <title>Coinlock | User Center - Eclipse Crypto</title>
    <!-- Vendor Bundle CSS -->
    <link rel="stylesheet" href="assets/css/vendor.bundle1.css?ver=110">
    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="assets/css/style1.css?ver=110">
</head>

<body class="user-dashboard">
    <!-- Topbar -->
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                        <form action="<?php echo e(route('coinlock.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            
                            <div class="user-content">
                               
                                <div class="user-panel">
                                    <?php if(session('error')): ?>
                                    <center>
                                    <div style=" color:white; margin-top: -2.2rem; background-color:tomato; border:1px solid tomato; border-radius:2px; margin-top:5px;">
                                        <p style=" color:white;"><?php echo e(session('error')); ?></p>
                                       
                                        
                                    </div>
                                    </center>
                                    <?php endif; ?>
                                    <?php if(session('success')): ?>
                                    <center>
                                    <div style=" color:white; margin-top: -2.2rem; background-color:rgb(19, 114, 19); border:1px solid rgb(19, 114, 19); border-radius:2px; margin-top:5px;">
                                        <p style=" color:white;"><?php echo e(session('success')); ?></p>
                                       
                                        
                                    </div>
                                    </center>
                                    <?php endif; ?>
                                    <?php if(session('coin_success')): ?>
                                    <center>
                                    <div style=" color:white; margin-top: -2.2rem; background-color:rgb(19, 114, 19); border:1px solid rgb(19, 114, 19); border-radius:2px; margin-top:5px;">
                                        <p style=" color:white;"><?php echo e(session('coin_success')); ?></p>
                                       
                                        
                                    </div>
                                    </center>
                                    <?php endif; ?>
                                    <h2 class="user-panel-title">Lock Eclipse or Naira and earn on the go</h2>
                                    <hr/>
                                       
                                        <div class="from-step-head">
                                            <h4>Step 1 : Click on any option to proceed.</h4>
                                            
                                        </div>
                                    <form action="#">
                                        <h5 class="user-panel-subtitle"></h5>
                                        <div class="gaps-1x"></div>
                                        <div class="payment-list">
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6" >
                                                    <div class="payment-item" onclick="myFunction()">
                                                        <input class="payment-check" type="radio" id="payeth" name="payOption" value="tranxETH">
                                                        <label for="payeth" style="background-color: #99089967;  border-color:#99089967;">
                                                            <div class="payment-icon payment-icon-eth" ><img src="images/icon-ethereum.png" alt="icon"></div>
                                                            <span class="payment-cur" style="color: white"><b>LOCK NAIRA</b></span>
                                                        </label>
                                                        <span></span>
                                                    </div>
                                                </div><!-- .col -->
                                                <div class="col-md-6 col-sm-6" >
                                                    <div class="payment-item" onclick="myFunction1()">
                                                        <input class="payment-check" type="radio" id="paylightcoin" name="payOption" value="tranxLTC">
                                                        <label for="paylightcoin" style="background-color: #13131352; border-color:#13131352;">
                                                            <div class="payment-icon payment-icon-ltc"><img class="payment-icon" src="images/icon-lightcoin.png" alt="icon"></div>
                                                            <span class="payment-cur" style="color: white"><b>LOCK ELPS</b></span>
                                                        </label>
                                                        <span></span>
                                                    </div>
                                                </div><!-- .col -->
                                                
                                            </div><!-- .row -->
                                        </div><!-- .payment-list -->
                                        <div class="gaps-1x"></div>
                                        <div class="from-step-head">
                                            <h4>Step 2 : Set your amount and lock days.</h4>
                                            
                                        </div>
                                        <h5 class="user-panel-subtitle" id="buytextp">Set amount of NGN you would like to Lock.
                                        </h5>
                                        <p id="buysubtextp">You can lock any amount of NGN and earn interests up to 12% annually</p>
                                        <h5 class="user-panel-subtitle" id="buytext"></h5>
                                        <p id="buysubtext"></p>
                                        <div class="gaps-1x"></div>
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="payment-calculator">
                                                    <div class="payment-get">
                                                        <label for="paymentGet">Lock Amount</label>
                                                        <div class="payment-input" id="payinput" style="display: none">
                                                            <input class="input-bordered" type="text" id="paymentGet" value="" name="amount_lock_elps">
                                                            <span class="payment-get-cur payment-cal-cur">ELPS</span>
                                                        </div>
                                                        <div class="gaps-2x d-md-none"></div>
                                                        <div class="payment-input"  id="payinput1" style="display: block">
                                                            <input class="input-bordered" type="text" id="paymentGet" value="" name="amount_lock">
                                                            <span class="payment-get-cur payment-cal-cur">NGN</span>
                                                        </div>
                                                    </div>
                                                   
                                                    <div class="payment-from">
                                                        <label for="paymentFrom">Lock days</label>
                                                        <div class="payment-input">
                                                            <select class="input-bordered" name="months" id="swalllet">
                                                                <option value="NULL">selcet lock days in months</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>

                                                            </select>
                                                            <!--<span class="payment-from-cur payment-cal-cur">MONTHS</span>-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gaps-2x d-md-none"></div>
                                            </div><!-- .col -->
                                            <div class="col-md-4">
                                               
                                                <div class="gaps-1x d-md-none"></div>
                                            </div><!-- .col -->
                                        </div><!-- .row -->
                                        <div class="gaps-2x"></div>
                                        <?php if($userscs): ?>
                                        <div class="payment-calculator-note"><i class="fas fa-info-circle"></i>Summary of coin lock order.</div>
                                        <div class="gaps-1x"></div>
                                        <div class="payment-summary">
                                            
                                            <div class="row">
                                               
                                                <div class="col-md-6">
                                                    <div class="payment-summary-item payment-summary-final">
                                                        <h6 class="payment-summary-title">Final Lock Amount</h6>
                                                        <div class="payment-summary-info">
                                                            
                                                            <?php if($userscs->amount_lock): ?>
                                                            <span class="payment-summary-amount"><?php echo e($userscs->amount_lock); ?></span> <span>NGN</span>
                                                            <?php endif; ?>
                                                            
                                                        </div>
                                                        <div class="payment-summary-info">
                                                            <?php if($userscs->elps_lock): ?>
                                                            <span class="payment-summary-amount"><?php echo e($userscs->elps_lock); ?></span> <span>ELPS</span>
                                                            <?php endif; ?>
                                                        </div>
                                                        
                                                    </div>
                                                </div><!-- .col -->
                                               
                                                <div class="col-md-6">
                                                    <div class="payment-summary-item payment-summary-tokens">
                                                        <h6 class="payment-summary-title">Total interest after <?php echo e($userscs->time_left); ?> months</h6>
                                                       
                                                        <div class="payment-summary-info">

                                                         <?php if($userscs->amount_lock): ?>
                                                         <span class="payment-summary-amount"><?php echo e($userscs->amount_lock * $userscs->time_left / 100); ?></span> <span>NGN</span>
                                                         <input class="input-bordered" type="text" id="time_later" value="<?php echo e($userscs->month); ?>" name="time_later" style="display:none" readonly>
                                                         <input class="input-bordered" type="text" id="timer" name="time_later" value="" style="display: block" readonly>
                                                         
                                                        </div>
                                                        <?php else: ?>
                                                        <span class="payment-summary-amount"><?php echo e($userscs->elps_lock * $userscs->time_left / 100); ?></span> <span>ELPS</span>
                                                        <input class="input-bordered" type="text" id="time_later" value="<?php echo e($userscs->month); ?>" name="time_later" style="display:none" readonly>
                                                         <input class="input-bordered" type="text" id="timer" name="time_later" value="" style="display: block" readonly>
                                                    </div>
                                                        <?php endif; ?>
                                                       
                                                       
                                                    </div>
                                                </div><!-- .col -->
                                                <hr/>
                                               
                                            </div><!-- .row -->
                                        </div><!-- .payment-summary -->
                                         <?php endif; ?>
                                        <?php if(count($users)==0): ?>
                                       
                                        <a href="#" class="btn btn-primary payment-btn" data-bs-toggle="modal" data-bs-target="#tranxETH" style="display: none;" id="buyToken"></a>

                                        
                                        <?php endif; ?>

                                        <?php if($userscs): ?>
                                        
                                        <?php if($userscs->status == 'Completed' && $userscs->amount_lock): ?>
                                        <a href="#" class="btn btn-primary payment-btn" data-bs-toggle="modal" data-bs-target="#tranxETH" style="display: block;" id="buyToken">LOCK NGN</a><br/>
                                        <?php endif; ?>
                                        <?php if($userscs->status == 'Completed' && $userscs->elps_lock): ?>
                                        <a href="#" class="btn btn-primary payment-btn" data-bs-toggle="modal" data-bs-target="#tranxETH" style="display: block;" id="buyToken">LOCK ELPS</a><br/>
                                        <?php endif; ?>
                                        <?php if($userscs->status == 'Running'): ?>
                                        <a href="#" class="btn btn-primary payment-btn"  style="display: block;" id="waittoken">Please wait for your present order to expire before a new lock.</a><br/>
                                        <?php endif; ?>
                                       
                                        <a href="<?php echo e('/coinlock/'.$userscs->id); ?>" class="btn btn-primary payment-btn"  style="display:none;" id="claimtoken" onclick="ourprocess()">Claim LOCK REWARD</a>
                                        
                                        <?php endif; ?>         

                               
                    </div><!-- .user-kyc -->
                </div><!-- .user-content -->
            </div><!-- .d-flex -->
        </div><!-- .container -->
    </div>
    <!-- UserWraper End -->

    <div class="modal fade" id="tranxETH" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="kyc-popup">
                    <h2 class="text-center">Confirm Information</h2> 
                    <h5 class="text-center">You are about Locking your NGN</h4>
                   
                    
                   
                    <div class="gaps-2x"></div>
                    <div class="text-center"><button class="btn btn-primary" type="submit">Proceed with Coin Lock</button></div>
                
                </div><!-- .modal-content -->
            </div><!-- .modal-content -->
        </div><!-- .modal-dialog -->
    </div><!-- Modal End -->
    
    <div class="modal fade" id="tranxLTC" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="kyc-popup">
                    <h2 class="text-center">Confirm Information</h2> 
                    <h5 class="text-center">You are about Locking your ELPS</h4>
                    
                    
                   
                    <div class="gaps-2x"></div>
                    <div class="text-center"><button class="btn btn-primary" type="submit"  onclick="starttimer()">Proceed with Coin Lock</button></div>
                </form>
                </div><!-- .modal-content -->
            </div><!-- .modal-content -->
        </div><!-- .modal-dialog -->
    </div><!-- Modal End -->
 
    
    <div class="footer-bar">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <span class="footer-copyright">Copyright 2022, <a href="#">Eclipse Crypto</a>. All Rights Reserved.</span>
                </div><!-- .col -->
                <div class="col-md-5 text-md-end">
                    <ul class="footer-links">
                        <li><a href="policy.html">Privacy Policy</a></li>
                        <li><a href="policy.html">Terms of Sales</a></li>
                    </ul>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div>
    <!-- FooterBar End -->
    <!-- JavaScript (include all script here) -->
    <script src="assets/js/jquery.bundle1.js?ver=110"></script>
    <script src="assets/js/script1.js?ver=110"></script>
    <script>
       
        
        
        function myFunction(){
            document.getElementById("buyToken").style.display = "block"
            document.getElementById("payinput").style.display = "none"
            document.getElementById("payinput1").style.display = "block"
            document.getElementById("buyToken").innerHTML = "LOCK NGN"
            document.getElementById("buytext").innerHTML = "Set amount of NGN you would like to Lock."
            document.getElementById("buysubtext").innerHTML = "You can lock any amount of NGN and earn interests up to 12% annually."
            document.getElementById("buytextp").style.display = "none"
            document.getElementById("buysubtextp").style.display = "none"

        }
        function myFunction1(){
            document.getElementById("buyToken").style.display = "block"
            document.getElementById("payinput").style.display = "block"
            document.getElementById("payinput1").style.display = "none"
            document.getElementById("buyToken").innerHTML = "LOCK ELPS"
            document.getElementById("buytext").innerHTML = "Set amount of ELPS you would like to Lock."
            document.getElementById("buysubtext").innerHTML = "You can lock any amount of ELPS and earn interests up to 12% annually."
            document.getElementById("buytextp").style.display = "none"
            document.getElementById("buysubtextp").style.display = "none"
        }
        function ourprocess(){
            localStorage.removeItem('currentTime');
                localStorage.removeItem('targetTime');
                

        }
        
  var interval;
           let months = document.getElementById('time_later').value;
           
           let minutes = months ? (months * 1) : null;
           let currentTime = localStorage.getItem('currentTime');
           let targetTime = localStorage.getItem('targetTime');
          
           if(targetTime == null && currentTime == null && months > 0){
               currentTime = new Date();
               targetTime = new Date(currentTime.getTime() + (minutes * 60000));
               localStorage.setItem('currentTime', currentTime);
               localStorage.setItem('targetTime', targetTime);
           }
        else {
            currentTime = new Date(currentTime);
            targetTime = new Date(targetTime);
        }
        if(checkComplete){
            interval = setInterval(checkComplete, 1000);
        }
        function checkComplete() {
            if(currentTime > targetTime){
                clearInterval(interval);
                document.getElementById('timer').value = 'Completed';
                if(months > 0){
                                    document.getElementById('claimtoken').style.display = 'block';

                }
                document.getElementById('waittoken').style.display = 'none';
                

            }
            else {
                currentTime = new Date();
               let timer = (targetTime - currentTime)/1000;
               var d = Math.floor(timer / (3600*24));
               var h = Math.floor(timer % (3600*24) / 3600);
               var m = Math.floor(timer % 3600/60);
               var s = Math.floor(timer % 60);

                
                //var mDisplay = d > 30 ? (d == 1 ? "day," : "days,")
               var dDisplay = d > 0 ? d + (d == 1 ? "day " : "days ") : ""
               var hDisplay = h > 0 ? h + (h == 1 ? "hour " : "hours ") : ""
               var mDisplay = m > 0 ? m + (m == 1 ? "minute " : "minutes ") : ""
               var sDisplay = s > 0 ? s + (s == 1 ? "second" : "seconds") : ""
                document.getElementById('timer').value = dDisplay + hDisplay + mDisplay + sDisplay
            }
        }
        document.onbeforeunload = function(){
            localStorage.setItem('currentTime', currentTime)
        }
        
         
             
    </script>
</body>

</html>


<?php /**PATH C:\xampp\htdocs\eclipse\resources\views/coinlock.blade.php ENDPATH**/ ?>