
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Eclipse Crypto is a modern and elegant landing page, created for Eclipse Agencies and digital crypto currency investment website.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- Site Title  -->
    <title>Account | User Center - Eclipse Crypto</title>
    <!-- Vendor Bundle CSS -->
    <link rel="stylesheet" href="assets/css/vendor.bundle1.css?ver=110">
    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="assets/css/style1.css?ver=110">
</head>

<body class="user-dashboard">
    <!-- Topbar -->
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                            
                            <div class="user-content">
                                <div class="user-panel">
                                    <h2 class="user-panel-title">
                                        <?php if(Auth::user()->status == 'Miner'): ?>
                                        Sell Eclipse Tokens

                                        <?php else: ?> 
                                         Buy and Sell Eclipse Tokens
                                        <?php endif; ?>
                                       </h2>
                                       <?php if(session('error_bal')): ?>
                                       <div style=" color:white;padding-left:5px; background-color:tomato; border:1px solid tomato; border-radius:2px; margin-top:5px;">
                                           <b><p style=" color:white;"><?php echo e(session('error_bal')); ?></p></b>
                                          
                                           
                                       </div>
                                       <?php endif; ?>
                                       <?php if(session('success')): ?>
                                       <div style=" color:white;padding-left:5px; background-color:rgb(19, 114, 19); border:1px solid rgb(19, 114, 19); border-radius:2px; margin-top:5px;">
                                           <b><p style=" color:white;"><?php echo e(session('success')); ?></p></b>
                                          
                                           
                                       </div>
                                       <?php endif; ?>
                                    <form action="<?php echo e(route('buy_sell')); ?>" method="post"> 
                                         <?php echo csrf_field(); ?>                                      
                                         <h5 class="user-panel-subtitle"></h5>
                                        <div class="gaps-1x"></div>
                                        <div class="payment-list">
                                            <div class="row"> 
                                                <?php if(Auth::user()->status == 'Miner'): ?>
                                                <div class="col-md-12 col-sm-12" >
                                                    <div class="payment-item" onclick="myFunction1()">
                                                        <input class="payment-check" type="radio" id="paylightcoin" name="payOption" value="tranxLTC">
                                                        <label for="paylightcoin" style="background-color: #ee0b0b; border-color:#ee0b0b;">
                                                            <div class="payment-icon payment-icon-ltc"><img class="payment-icon" src="images/icon-lightcoin.png" alt="icon"></div>
                                                            <span class="payment-cur" style="color: white"><b>Sell</b></span>
                                                        </label>
                                                        <span></span>
                                                    </div>
                                                </div>
                                                <?php else: ?> 
                                                <div class="col-md-6 col-sm-6" >
                                                   
                                                    <div class="payment-item" onclick="myFunction()">
                                                        <input class="payment-check" type="radio" id="payeth" name="payOption" value="tranxETH">
                                                        <label for="payeth" style="background-color: rgb(20, 138, 20);  border-color:rgb(20, 138, 20);">
                                                            <div class="payment-icon payment-icon-eth" ><img src="images/icon-ethereum.png" alt="icon"></div>
                                                            <span class="payment-cur" style="color: white"><b>Buy</b></span>
                                                        </label>
                                                        <span></span>
                                                    </div>
                                                </div><!-- .col -->
                                                <div class="col-md-6 col-sm-6" >
                                                    <div class="payment-item" onclick="myFunction1()">
                                                        <input class="payment-check" type="radio" id="paylightcoin" name="payOption" value="tranxLTC">
                                                        <label for="paylightcoin" style="background-color: #ee0b0b; border-color:#ee0b0b;">
                                                            <div class="payment-icon payment-icon-ltc"><img class="payment-icon" src="images/icon-lightcoin.png" alt="icon"></div>
                                                            <span class="payment-cur" style="color: white"><b>Sell</b></span>
                                                        </label>
                                                        <span></span>
                                                    </div>
                                                </div><!-- .col -->
                                                <?php endif; ?>
                                                
                                                
                                            </div><!-- .row -->
                                        </div><!-- .payment-list -->
                                        <div class="gaps-1x"></div>
                                        <h5 class="user-panel-subtitle" id="buytext"></h5>
                                        <p id="buysubtext"></p>
                                        <div class="gaps-1x"></div>
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="payment-calculator">
                                                    <div class="payment-get">
                                                        <label for="paymentGet">Amount of Tokens (ELPS)</label>
                                                        <div class="payment-input">
                                                            <input class="input-bordered" type="number" id="paymentGet" name="elps" value="" onchange="process()">
                                                            
                                                        </div>
                                                       <div class="gaps-2x"></div>
                                                       <center><span class="btn btn-primary payment-btn">covert</span></center>
                                                    </div>
                                                    <div style="margin-bottom: -200px">
                                                        
                                                    </div>
                                                    
                                                    
                                                    <div class="payment-from">
                                                        
                                                        <label for="paymentFrom">Payment Amount (USD)</label>
                                                        <div class="payment-input">
                                                            <input class="input-bordered" type="number" id="paymentFrom" name="usd" value="" onchange="pro()">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gaps-2x d-md-none"></div>
                                            </div><!-- .col -->
                                            <div class="col-md-4">
                                               
                                                <div class="gaps-1x d-md-none"></div>
                                            </div><!-- .col -->
                                        </div><!-- .row -->
                                        <div class="gaps-1x"></div>
                                        <div class="payment-calculator-note"><i class="fas fa-info-circle"></i>The calculator helps you to convert required currency to ELPS tokens.</div>
                                        <div class="gaps-3x"></div>
                                        <div class="payment-summary">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="payment-summary-item payment-summary-final">
                                                        <h6 class="payment-summary-title" >Final Payment</h6>
                                                        <div class="payment-summary-info">
                                                            <span class="payment-summary-amount" id="usds">0</span> <span>usd</span>
                                                        </div>
                                                    </div>
                                                </div><!-- .col -->
                                               
                                                <div class="col-md-6">
                                                    <div class="payment-summary-item payment-summary-tokens">
                                                        <h6 class="payment-summary-title" >Tokens Received</h6>
                                                        <div class="payment-summary-info">
                                                            <span class="payment-summary-amount" id="tokens">0</span> <span>ELPS</span>
                                                        </div>
                                                    </div>
                                                </div><!-- .col -->
                                            </div><!-- .row -->
                                        </div><!-- .payment-summary -->
                                        <a href="#" class="btn btn-primary payment-btn" data-bs-toggle="modal" data-bs-target="#tranxETH" style="display: none;" id="buyToken"></a>
                                    <!-- form -->
                               
                    </div><!-- .user-kyc -->
                </div><!-- .user-content -->
            </div><!-- .d-flex -->
        </div><!-- .container -->
    </div>
    <!-- UserWraper End -->
    <div class="modal fade" id="tranxETH" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="tranx-popup">
                    <h5>Transaction Details</h5>
                    <div class="tranx-payment-details">
                        <p>Hi, Your transaction <strong>(BUY)</strong> is <strong>Pending Payment</strong><br> You will receive <strong id="tok"></strong> tokens once paid.</p>
                        <h6>Please make your Payment to the Account below</h6>
                        <div class="tranx-payment-info">
                            <span class="tranx-copy-feedback copy-feedback"></span>
                            <em class="fab fa-ethereum"></em>
                            <input type="text" class="tranx-payment-address" value="<?php echo e($admin->address); ?>" disabled>
                            <a class="tranx-payment-copy copy-clipboard-modal" data-clipboard-text="<?php echo e($admin->address); ?>"><em class="ti ti-files"></em></a>
                        </div><!-- .tranx-payment-info -->
                        <!-- @updated  on v1.0.1 -->
                        <ul class="tranx-info-list">
                            
                        </ul><!-- .tranx-info-list -->
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="tranx-info-qr">
                                    <ul class="btn-grp guttar-20px">
                                        <li><button class="btn btn-primary" type="submit">I want this token</button></li>
                                        <li><a href="#" class="btn btn-xs btn-uline btn-uline-danger" data-bs-dismiss="modal">I Don't Want This</a></li>
                                    </ul>
                                </div>
                            </div><!-- .col -->
                            <div class="col-sm-7">
                                <div class="note note-info">
                                    <em class="fas fa-info-circle"></em>
                                    <p>Transactions may take up to 5 minutes to reflect.</p>
                                </div>
                                <div class="gaps-1x"></div>
                                <div class="note note-danger">
                                    <em class="fas fa-info-circle"></em>
                                    <p>Do not make payment through any external exchange platform, all payment must be made on this website.s to reflect.</p>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tranx-payment-details -->
                </div><!-- .tranx-popup -->
            </div><!-- .modal-content -->
        </div><!-- .modal-dialog -->
    </div>
</div>

     <!-- Modal End -->
     <!-- Modal End -->
    <div class="modal fade" id="tranxLTC" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="tranx-popup">
                    <h5>Transaction Details</h5>
                    <div class="tranx-payment-details">
                        <p>Hi, Your transaction <strong>(SELL)</strong> is <strong>Pending</strong><br> A total of <strong id="toks"></strong> tokens will be deducted from your account.</p>
                        <h6>Please make your Payment to the bellow Address</h6>
                        <div class="tranx-payment-info">
                            <span class="tranx-copy-feedback copy-feedback"></span>
                            <em class="fab fa-ethereum"></em>
                            <input type="text" class="tranx-payment-address" value="<?php echo e($admin->address); ?>}" disabled>
                            <a class="tranx-payment-copy copy-clipboard-modal" data-clipboard-text="<?php echo e($admin->address); ?>"><em class="ti ti-files"></em></a>
                        </div><!-- .tranx-payment-info -->
                        <!-- @updated  on v1.0.1 -->
                        <div class="gaps-3x"></div>
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="tranx-info-qr">
                                    
                                    <ul class="btn-grp guttar-20px">
                                        <li><button class="btn btn-primary">Sell this token</button></li>
                                            
                                    </form>
                                        <li><a href="#" class="btn btn-xs btn-uline btn-uline-danger" data-bs-dismiss="modal">I Don't Want This</a></li>
                                    </ul>
                                </div>
                            </div><!-- .col -->
                            <div class="col-sm-7">
                                <div class="note note-info">
                                    <em class="fas fa-info-circle"></em>
                                    <p>Transactions may take up to 5 minutes to reflect.</p>
                                </div>
                                <div class="gaps-1x"></div>
                                <div class="note note-danger">
                                    <em class="fas fa-info-circle"></em>
                                    <p>Do not make payment through any external exchange platform, all payment must be made on this website.s to reflect.</p>
                                </div>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tranx-payment-details -->
                </div><!-- .tranx-popup -->
            </div><!-- .modal-content -->
        </div><!-- .modal-dialog -->
    </div>
    <!-- Modal End -->
    
    <div class="footer-bar">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <span class="footer-copyright">Copyright 2022, <a href="#">Eclipse Crypto</a>. All Rights Reserved.</span>
                </div><!-- .col -->
                <div class="col-md-5 text-md-end">
                    <ul class="footer-links">
                        <li><a href="policy.html">Privacy Policy</a></li>
                        <li><a href="policy.html">Terms of Sales</a></li>
                    </ul>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div>
    <!-- FooterBar End -->
    <!-- JavaScript (include all script here) -->
    <script src="assets/js/jquery.bundle1.js?ver=110"></script>
    <script src="assets/js/script1.js?ver=110"></script>
    <script>
        function myFunction(){
            document.getElementById("buyToken").style.display = "block"
           
            document.getElementById("buyToken").innerHTML = "BUY TOKEN"
            document.getElementById("buytext").innerHTML = "Set amount of ELPS tokens you would like to purchase."
            document.getElementById("buysubtext").innerHTML = "To become a part of the Eclipse Crypto project and purchase of ELPS token will only be possible after payment made and receving an approval. As you like to participate our project, please select payment method and enter the amount of ELPS tokens you wish to purchase."
        }
        function myFunction1(){
            document.getElementById("buyToken").style.display = "block"
            document.getElementById("buyToken").innerHTML = "SELL TOKEN"
            document.getElementById("buytext").innerHTML = "Set amount of ELPS tokens you would like to sell."
            document.getElementById("buysubtext").innerHTML = "To become a part of the Eclipse Crypto project and sell ELPS token will only be possible after payment made and receving an approval. As you like to participate our project, please enter the amount of ELPS tokens you wish to sell."

        }
        function process(){
            let values = document.getElementById('paymentGet').value;
            document.getElementById('paymentFrom').value = values;
            document.getElementById('usds').innerHTML = values;
            document.getElementById('tokens').innerHTML = values;
            document.getElementById('tok').innerHTML = values + ' ELPS';
            document.getElementById('toks').innerHTML = values + ' ELPS';

        }
        function pro(){
            let values = document.getElementById('paymentFrom').value;
            document.getElementById('paymentGet').value = values;
            document.getElementById('usds').innerHTML = values;
            document.getElementById('tokens').innerHTML = values;
            document.getElementById('tok').innerHTML = values + ' ELPS';
            document.getElementById('toks').innerHTML = values + ' ELPS';

        }
        
       

    </script>
</body>

</html>


<?php /**PATH C:\xampp\htdocs\eclipse\resources\views/buy_sell.blade.php ENDPATH**/ ?>