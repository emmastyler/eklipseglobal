<?php $__env->startSection('content'); ?>
<main class="nk-pages">
    <div class="section" style="background-color: #F7F8FF">
        <div class="container">
            <div class="nk-block">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-head text-center">
                            <h2 class="title title-regular">Congratulations!</h2>
                            <p class="wide-sm">We’re happy to have you join us....</p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="row justify-content-between">
                            
                            <div class="col-md-3">
                               
                            </div>
                                 
                            <div class="col-md-6">
                                <div class="feature feature-center card card-s3 card-lg-xy">
                                    <div class="feature-icon feature-icon-lg-s2 pb-4 mt-0 mx-auto">
                                        <img src="images/icons/icon-t3.png" alt="">
                                    </div>
                                    <div class="feature-text">
                                        <h4 class="title title-lg">Check your Inbox.</h4>
                                        <p>Click the link we sent to complete your account set-up. If you didn't receive the email, we will gladly send you another.</p><br/>
                                        <?php if(session('status') == 'verification-link-sent'): ?>
                                        <div class="mb-4 font-medium text-sm text-green-600" style="color: #2BC9B4">
                                            <?php echo e(__('A new verification link has been sent to the email address you provided during registration.')); ?>

                                        </div>
                                    <?php endif; ?>
                                        <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                                            <?php echo csrf_field(); ?>
                            
                                            <div>
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['style' => 'background-color:#2BC9B4']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'background-color:#2BC9B4']); ?>
                                                    <?php echo e(__('Resend Verification Email')); ?>

                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                        </form><br/>
                                        
                                        <div class="mt-4 flex items-center justify-between">

                                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                                <?php echo csrf_field(); ?>
                                
                                                <button type="submit" class="btn btn-md btn-outline btn-secondary">
                                                    <?php echo e(__('ok')); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                 
                            <div class="col-md-3">
                                
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- // -->
</main>
<script>
   
</script>
<?php $__env->stopSection(); ?>  
       

       

        


<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclipse\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>